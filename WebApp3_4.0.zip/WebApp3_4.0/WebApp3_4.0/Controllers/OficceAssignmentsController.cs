﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApp3_4._0.Context;
using WebApp3_4._0.Models;

namespace WebApp3_4._0.Controllers
{
    public class OficceAssignmentsController : Controller
    {
        private readonly bdContext _context;

        public OficceAssignmentsController(bdContext context)
        {
            _context = context;
        }

        // GET: OficceAssignments
        public async Task<IActionResult> Index()
        {
            var bdContext = _context.OficceAssignment.Include(o => o.Instructor);
            return View(await bdContext.ToListAsync());
        }

        // GET: OficceAssignments/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oficceAssignment = await _context.OficceAssignment
                .Include(o => o.Instructor)
                .FirstOrDefaultAsync(m => m.oficceAssignmentID == id);
            if (oficceAssignment == null)
            {
                return NotFound();
            }

            return View(oficceAssignment);
        }

        // GET: OficceAssignments/Create
        public IActionResult Create()
        {
            ViewData["InstructorID"] = new SelectList(_context.Instructor, "ID", "ID");
            return View();
        }

        // POST: OficceAssignments/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("oficceAssignmentID,InstructorID,Location")] OficceAssignment oficceAssignment)
        {
            if (ModelState.IsValid)
            {
                _context.Add(oficceAssignment);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["InstructorID"] = new SelectList(_context.Instructor, "ID", "ID", oficceAssignment.InstructorID);
            return View(oficceAssignment);
        }

        // GET: OficceAssignments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oficceAssignment = await _context.OficceAssignment.FindAsync(id);
            if (oficceAssignment == null)
            {
                return NotFound();
            }
            ViewData["InstructorID"] = new SelectList(_context.Instructor, "ID", "ID", oficceAssignment.InstructorID);
            return View(oficceAssignment);
        }

        // POST: OficceAssignments/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("oficceAssignmentID,InstructorID,Location")] OficceAssignment oficceAssignment)
        {
            if (id != oficceAssignment.oficceAssignmentID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(oficceAssignment);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OficceAssignmentExists(oficceAssignment.oficceAssignmentID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["InstructorID"] = new SelectList(_context.Instructor, "ID", "ID", oficceAssignment.InstructorID);
            return View(oficceAssignment);
        }

        // GET: OficceAssignments/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oficceAssignment = await _context.OficceAssignment
                .Include(o => o.Instructor)
                .FirstOrDefaultAsync(m => m.oficceAssignmentID == id);
            if (oficceAssignment == null)
            {
                return NotFound();
            }

            return View(oficceAssignment);
        }

        // POST: OficceAssignments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var oficceAssignment = await _context.OficceAssignment.FindAsync(id);
            _context.OficceAssignment.Remove(oficceAssignment);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OficceAssignmentExists(int id)
        {
            return _context.OficceAssignment.Any(e => e.oficceAssignmentID == id);
        }
    }
}
