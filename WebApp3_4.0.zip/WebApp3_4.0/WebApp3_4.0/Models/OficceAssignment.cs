﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp3_4._0.Models
{
    public class OficceAssignment
    {
        [Key]
        public int oficceAssignmentID { get; set; }
        public int InstructorID { get; set; }
        [ForeignKey("InstructorID")]
        public string Location { get; set; }
        public virtual Instructor Instructor { get; set; }
    }



}

