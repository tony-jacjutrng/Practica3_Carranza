﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp3_4._0.Models
{
    public class Course
    {
        [Key]

        public int CourseID { get; set; }
        public string Title { get; set; }
        public string Credits { get; set; }
        public int DepartmentID { get; set; }
        [ForeignKey("DepartamentoID")]
        public virtual Department Department { get; set; }

    }
}
