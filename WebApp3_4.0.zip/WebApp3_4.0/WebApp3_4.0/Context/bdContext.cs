﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApp3_4._0.Models;

namespace WebApp3_4._0.Context
{
    public class bdContext : DbContext
    {

        public bdContext(DbContextOptions<bdContext> options) :
  base(options)
        {

        }

        public DbSet<Course> Course { get; set; }
        public DbSet<CourseAssignment> CourseAssignment { get; set; }
        public DbSet<Department> Department { get; set; }
        public DbSet<Enrollment> Enrollment { get; set; }
        public DbSet<Instructor> Instructor { get; set; }
        public DbSet<OficceAssignment> OficceAssignment { get; set; }
        public DbSet<Student> Student { get; set; }


    }
}
